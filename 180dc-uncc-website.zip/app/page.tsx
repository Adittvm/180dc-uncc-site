import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mail, MapPin, Users, Target, Briefcase, Heart } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-xl font-bold text-primary">180DC UNCC</span>
            </div>
            <div className="hidden md:flex items-center space-x-6">
              <a href="#about" className="text-foreground hover:text-primary transition-colors">
                About
              </a>
              <a href="#projects" className="text-foreground hover:text-primary transition-colors">
                Projects
              </a>
              <a href="#join" className="text-foreground hover:text-primary transition-colors">
                Join Us
              </a>
              <a href="#contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-8 mb-8">
            {/* 180DC Logo Placeholder */}
            <div className="w-24 h-24 bg-secondary rounded-lg flex items-center justify-center">
              <span className="text-secondary-foreground font-bold text-sm">180DC</span>
            </div>
            {/* UNC Charlotte Logo Placeholder */}
            <div className="w-24 h-24 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">UNCC</span>
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-balance mb-6">
            180 Degrees Consulting at <span className="text-primary">UNC Charlotte</span>
          </h1>

          <p className="text-xl text-muted-foreground text-balance max-w-4xl mx-auto mb-8">
            180 Degrees Consulting at UNC Charlotte empowers students to deliver pro bono consulting services to
            nonprofits and social enterprises while gaining real-world experience in strategy, finance, and data-driven
            problem solving.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              Join Our Team
            </Button>
            <Button size="lg" variant="outline">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About Us</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
              We are a student-led consulting organization dedicated to creating positive social impact through
              strategic consulting services.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Social Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  We partner with nonprofits and social enterprises to solve complex challenges and drive meaningful
                  change in our community.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle>Student Development</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Our members gain hands-on consulting experience, develop professional skills, and build networks while
                  making a difference.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Strategic Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  We deliver data-driven insights and strategic recommendations across finance, operations, marketing,
                  and organizational development.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Projects</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
              Explore some of our recent consulting engagements and the impact we've made with our nonprofit partners.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg mb-4 flex items-center justify-center">
                  <Briefcase className="w-12 h-12 text-primary" />
                </div>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Local Food Bank</CardTitle>
                  <Badge variant="secondary">Strategy</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Developed a comprehensive operational efficiency strategy that increased food distribution capacity by
                  35% while reducing costs.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-full h-48 bg-gradient-to-br from-secondary/20 to-primary/20 rounded-lg mb-4 flex items-center justify-center">
                  <Users className="w-12 h-12 text-secondary" />
                </div>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Youth Mentorship Program</CardTitle>
                  <Badge variant="outline">Marketing</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Created a digital marketing strategy and brand identity that doubled program enrollment and improved
                  community engagement.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg mb-4 flex items-center justify-center">
                  <Target className="w-12 h-12 text-primary" />
                </div>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Environmental Initiative</CardTitle>
                  <Badge variant="secondary">Finance</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Conducted financial analysis and developed a sustainable funding model for a local environmental
                  conservation project.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Join Us Section */}
      <section id="join" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Team</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
              Ready to make an impact while developing your consulting skills? Here's how you can get involved with
              180DC UNCC.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-6">What We're Looking For</h3>
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <span>Passionate students interested in consulting and social impact</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-secondary rounded-full mt-2 flex-shrink-0"></div>
                  <span>Strong analytical and problem-solving skills</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <span>Excellent communication and teamwork abilities</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-secondary rounded-full mt-2 flex-shrink-0"></div>
                  <span>Commitment to making a positive difference</span>
                </li>
              </ul>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Application Process</CardTitle>
                <CardDescription>Join us in three simple steps</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <span>Submit your application and resume</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <span>Participate in our interview process</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <span>Join our training program and start consulting</span>
                </div>
                <Button className="w-full mt-6 bg-primary hover:bg-primary/90">Apply Now</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
              Have questions about our organization or interested in partnering with us? We'd love to hear from you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">Email</p>
                    <p className="text-muted-foreground">180dc@uncc.edu</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="font-semibold">Location</p>
                    <p className="text-muted-foreground">
                      UNC Charlotte Campus
                      <br />
                      Charlotte, NC
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>We'll get back to you as soon as possible</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">First Name</label>
                    <input
                      className="w-full mt-1 px-3 py-2 border border-border rounded-md bg-input"
                      placeholder="John"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Last Name</label>
                    <input
                      className="w-full mt-1 px-3 py-2 border border-border rounded-md bg-input"
                      placeholder="Doe"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <input
                    className="w-full mt-1 px-3 py-2 border border-border rounded-md bg-input"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Message</label>
                  <textarea
                    className="w-full mt-1 px-3 py-2 border border-border rounded-md bg-input h-32"
                    placeholder="Tell us how we can help..."
                  ></textarea>
                </div>
                <Button className="w-full bg-primary hover:bg-primary/90">Send Message</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <span className="text-xl font-bold text-primary">180DC UNCC</span>
              <p className="text-muted-foreground mt-2">Empowering students, transforming communities</p>
            </div>
            <div className="flex space-x-6">
              <a href="#about" className="text-muted-foreground hover:text-primary transition-colors">
                About
              </a>
              <a href="#projects" className="text-muted-foreground hover:text-primary transition-colors">
                Projects
              </a>
              <a href="#join" className="text-muted-foreground hover:text-primary transition-colors">
                Join Us
              </a>
              <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors">
                Contact
              </a>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 180 Degrees Consulting at UNC Charlotte. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
